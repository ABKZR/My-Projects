function myFunction(){
    alert('Your Item Has been Added \n Press Ok To Continue')
}