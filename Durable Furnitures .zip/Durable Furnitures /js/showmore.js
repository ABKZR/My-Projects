let show = "";
function andn(){
    show += "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Molestias deserunt consectetur saepe libero at sint officia. Soluta impedit voluptate dolores sint obcaecati consequatur, in maiores molestiae ut, quos similique accusantium quisquam natus recusandae inventore repellat minima necessitatibus! Voluptatum, mollitia voluptas?";
    document.getElementById('summer').innerHTML = show;
}
let abc = " "; 
function and(){
    document.getElementById('summer').innerHTML = abc;
}